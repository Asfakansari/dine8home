
var krms_config ={	
	'ApiUrl' : "http://dine8home.com/mobileapp/api",
	'DialogDefaultTitle' : "Smart Fox app",
	'pushNotificationSenderid' : "897419858110",
	'facebookAppId' : "YOUR_FACEBOOK_APP_ID",
	'APIHasKey' : "AIzaSyBORMfzaBt1HThbTogASxYADh4LX862g_E"
};